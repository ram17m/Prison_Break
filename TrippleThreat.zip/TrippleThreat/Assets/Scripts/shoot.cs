﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shoot : MonoBehaviour {
	public float speed;
	public Rigidbody2D bullet;

	// Use this for initialization
	void Start () {
		bullet = GetComponent<Rigidbody2D> ();
	}
	
	// Update is called once per frame
	void Update () {


	}





}
